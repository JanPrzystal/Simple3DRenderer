#pragma once
#include "Vector2.h"
#include "Vector4.h"
#ifndef STRING
#include <string>
#define STRING
#endif // !"STRING"


struct Vector3 {
	float x, y, z;

	void setValues(float x, float y, float z) {
		this->x = x;
		this->y = y;
		this->z = z;
	}
	Vector3(float x, float y, float z) {
		setValues(x, y, z);
	}

	Vector3(const Vector3& vec) {
		this->x = vec.x;
		this->y = vec.y;
		this->z = vec.z;
	}

	Vector3() {
		setValues(0.0f, 0.0f, 0.0f);
	}

	float magnitude() {
		return sqrtf(this->x * this->x + this->y * this->y + this->z * this->z);
	}

	Vector2 toVector2() {
		return Vector2(this->x, this->y);
	}
	Vector4 toVector4() {
		return Vector4(this->x, this->y, this->z, 1.0f);
	}
	Vector3 operator + (float number) {
		return Vector3(this->x + number, this->y + number, this->z + number);
	}
	Vector3 operator / (float number) {
		return Vector3(this->x / number, this->y / number, this->z / number);
	}
	Vector3 operator * (float number) {
		return Vector3(this->x * number, this->y * number, this->z * number);
	}
	float operator * (Vector3& vec) {
		return this->x * vec.x + this->y * vec.y + this->z * vec.z;
	}
	Vector3 operator * (Matrix4& matrix) {
		Vector4 vec4 = toVector4();
		vec4 = vec4 * matrix;
		//std::cout << "matrix mul " << vec4.toString() << std::endl;
		vec4 = vec4 / vec4.w;
		//std::cout << "divided " << vec4.toString() << std::endl;

		return Vector3(vec4.x, vec4.y, vec4.z);
	}
	Vector3 operator - (Vector3& vec) {
		return Vector3(
			this->x - vec.x,
			this->y - vec.y,
			this->z - vec.z
		);
	}
	Vector3 cross(Vector3& vec) {
		Vector3 normal(
			this->y * vec.z - this->z * vec.y,
			this->z * vec.x - this->x * vec.z,
			this->x * vec.y - this->y * vec.x
		);
		return normal;
	}
	Vector3 normalize() {
		return *this / magnitude();
	}

	std::string toString() {
		return "Vector3: [" + std::to_string(x) + ", " + std::to_string(y) + ", " + std::to_string(z) + "]";
	}
};