#include <iostream>
#include <chrono>
#include <string.h>
//#include <SDL.h>
#include "SdlWindowRenderer.cpp"

#define SDL_MAIN_HANDLED

const int SCREEN_HEIGHT = 800;
const int SCREEN_WIDTH = 800;
const int WIDTH_HALF = SCREEN_WIDTH / 2;
const int HEIGHT_HALF = SCREEN_HEIGHT / 2;

Mesh* rotateMesh(Mesh* mesh, Matrix4& rotation) {
	std::vector<Triangle>& triangles = mesh->triangles;
	for (Triangle& t : triangles) {
		t.vertices[0] = t.vertices[0] * rotation;
		t.vertices[1] = t.vertices[1] * rotation;
		t.vertices[2] = t.vertices[2] * rotation;
	}

	return mesh;
}

#undef main
// main ... The main function, right now it just calls the initialization of SDL.
int main(int argc, char* argv[]) {

	WindowRenderer* wr = new SdlWindowRenderer(SCREEN_WIDTH, SCREEN_HEIGHT);

	Color color(255, 255, 255, SDL_ALPHA_OPAQUE);

	(*wr).setDrawColor(color);

	float aspectRatio = (float)SCREEN_WIDTH / (float)SCREEN_HEIGHT;
	Camera camera(aspectRatio, 0.1f, 1000.0f, 120.0f);

	//std::cout << camera.projectionMatrix.toString() << std::endl;

	Vector3 v1(-1.0f, 1.0f, 1.0f);
	Vector3 v2(-1.0f, -1.0f, 1.0f);
	Vector3 v3(1.0f, -1.0f, 1.0f);
	Vector3 v4(1.0f, 1.0f, 1.0f);
	Vector3 v5(-1.0f, 1.0f, -1.0f);
	Vector3 v6(-1.0f, -1.0f, -1.0f);
	Vector3 v7(1.0f, -1.0f, -1.0f);
	Vector3 v8(1.0f, 1.0f, -1.0f);

	//std::cout << v2.toString() << std::endl;

	Triangle t1(v3, v2, v1);
	Triangle t2(v1, v4, v3);
	Triangle t3(v1, v2, v5);
	Triangle t4(v5, v2, v6);
	Triangle t5(v8, v3, v4);
	Triangle t6(v8, v7, v3);
	Triangle t7(v5, v6, v7);
	Triangle t8(v7, v8, v5);
	Triangle t9(v5, v4, v1);//t1
	Triangle t10(v8, v4, v5);//t2
	Triangle t11(v2, v3, v6);//b1
	Triangle t12(v7, v6, v3);//b2

	//std::cout << t3.toString() << std::endl;
	//std::cout << t8.toString() << std::endl;


	std::vector<Triangle> triangles = { t1, t2, t3, t4, t5, t6, t7, t8, t9, t10, t11, t12 };

	Mesh* mesh = new Mesh(triangles);

	uint64_t previousTime = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();

	//wr->drawMesh(mesh, color, camera, 0.0f);

	int counter = 0;
	float rotation = (PI / 120.0f);

	while (counter < 380) {
		uint64_t  beforeTime = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
		//std::cout << "last frame duration " << beforeTime - previousTime << "ms" << std::endl;

		wr->clearScreen();

		Matrix4 rotX, rotY, rotZ;
		//fTheta += (PI/360.0f);//* fElapsedTime;

		rotX = Matrix4(cosf(rotation * 0.8f), cosf(rotation * 0.8f), 1.0f, 1.0f);
		rotX.matrix[0][1] = sinf(rotation * 0.8f);
		rotX.matrix[1][0] = -sinf(rotation * 0.8f);

		rotY = Matrix4(cosf(rotation), 1.0f, cosf(rotation), 1.0f);
		rotY.matrix[0][2] = sinf(rotation);
		rotY.matrix[2][0] = -sinf(rotation);

		//rotZ = Matrix4(1.0f, cosf(fTheta * 0.5f), cosf(fTheta * 0.5f), 1.0f);
		//rotZ.matrix[1][2] = sinf(fTheta * 0.5f);
		//rotZ.matrix[2][1] = -sinf(fTheta * 0.5f);

		rotateMesh(mesh, rotX);
		rotateMesh(mesh, rotY);

		wr->drawMesh(mesh, color, camera, (600 - counter)/100.0f);

		uint64_t  afterTime = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
		uint64_t dTime = afterTime - beforeTime;
		uint64_t delay = 0;
		if (dTime < 16)
			delay = 16 - dTime;
		std::string lastText = "last frame duration " + std::to_string(beforeTime - previousTime);
		std::string durationText = "frame " + std::to_string(counter) + "; duration " + std::to_string(beforeTime - previousTime);
		std::string text = lastText + "\n" + durationText;
		//printf(text.c_str());
		wr->drawText(text);
		//std::cout << "frame " << counter << "; duration " << afterTime - beforeTime << "ms" << std::endl;
		previousTime = beforeTime;

		wr->present();

		SDL_Delay(delay);
		counter++;
	}
	std::string endText = "end";
	wr->drawText(endText);
	wr->present();

	//Adding a delay.
	SDL_Delay(1 * 1000);

	delete mesh;
	delete wr;

	return 0;
}

//Vector3 v11(122.0f, 8.0f, 10.0f);
//Vector3 v12(54.0f, 77.0f, 10.0f);
//Vector3 v13(30.0f, 30.0f, 10.0f);

////Just printing out hello world if everything is working properly.
//std::cout << "v11 " << v11.toString() << std::endl;

//Triangle t9(v11, v12, v13);

//wr.drawTriangle(t9, color);
