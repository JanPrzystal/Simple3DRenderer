#ifndef VECTOR3
#define VECTOR3
#include "Vector3.h"

struct Object3D {
	Vector3 position;

	void setPosition(float x, float y, float z) {
		position.x = x;
		position.y = y;
		position.z = z;
	}
	void setPosition(Vector3 vector) {
		this->position = vector;
	}

	Object3D(float x, float y, float z) {
		Object3D();
		setPosition(x, y, z);
	}

	Object3D() {
		position = Vector3();
	}

};

#endif