#pragma once
#ifndef PI
const float PI = 3.14159f;
#endif 
#ifndef MATH
#include <corecrt_math.h>
#define MATH
#endif
#include<iostream>
#include <sstream>

struct Matrix4 {
	float matrix[4][4] = { 0.0f };

	Matrix4() {

	}
	Matrix4(float m00, float m11, float m22, float m33) {
		matrix[0][0] = m00;
		matrix[1][1] = m11;
		matrix[2][2] = m22;
		matrix[3][3] = m33;
	}

	static Matrix4 getCameraMatrix(float aspectRatio, float nearPlane, float farPlane, float fov) {
		float fovRad = 1.0f / tanf(fov * 0.5f / 180.0f * PI);

		//std::cout << "in tan " << (fov * 0.5f / 180.0f * PI) << std::endl;
		//std::cout << "tan " << tanf(fov * 0.5f / 180.0f * PI) << std::endl;
		//std::cout << "fovRad " << fovRad << std::endl;

		Matrix4 cameraMatrix(aspectRatio * fovRad, fovRad, farPlane / (farPlane - nearPlane), 0.0f);
		cameraMatrix.matrix[3][2] = (-farPlane * nearPlane) / (farPlane - nearPlane);
		cameraMatrix.matrix[2][3] = 1.0f;

		return cameraMatrix;
	}

	std::string toString() {
		std::stringstream stream;
		for (uint8_t i = 0; i < 4; i++) {
			stream << "[";
			for (uint8_t j = 0; j < 4; j++) {
				stream << matrix[i][j] << ", ";
			}
			stream << "]\n";
		}
		return stream.str();
	}

};