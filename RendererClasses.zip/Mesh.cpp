#ifndef TRIANGLE
#define TRIANGLE
#include "Triangle.cpp"
#endif
#include <vector>

struct Mesh {
	std::vector<Triangle> triangles;

	Mesh(std::vector<Triangle> triangles) {
		this->triangles = triangles;
	}

};